# Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

import unittest


class TestCashierClosing(unittest.TestCase):
	pass
